package com.optimizer.coloros16.utils

import android.util.Log
import com.optimizer.coloros16.ModuleEntry

/**
 * 日志工具类
 *
 * 提供统一的日志输出接口
 */
object Logger {

    private const val TAG_PREFIX = "ColorOS16"
    private var isDebugEnabled = true
    private var logLevel = LogLevel.DEBUG

    enum class LogLevel {
        VERBOSE, DEBUG, INFO, WARN, ERROR
    }

    /**
     * 初始化日志系统
     */
    fun init(debugEnabled: Boolean = true, level: LogLevel = LogLevel.DEBUG) {
        isDebugEnabled = debugEnabled
        logLevel = level
        i(TAG_PREFIX, "Logger initialized - Debug: $debugEnabled, Level: $level")
    }

    /**
     * 详细日志
     */
    fun v(tag: String, message: String) {
        if (isDebugEnabled && logLevel.ordinal <= LogLevel.VERBOSE.ordinal) {
            Log.v("$TAG_PREFIX/$tag", message)
        }
    }

    /**
     * 调试日志
     */
    fun d(tag: String, message: String) {
        if (isDebugEnabled && logLevel.ordinal <= LogLevel.DEBUG.ordinal) {
            Log.d("$TAG_PREFIX/$tag", message)
        }
    }

    /**
     * 信息日志
     */
    fun i(tag: String, message: String) {
        if (logLevel.ordinal <= LogLevel.INFO.ordinal) {
            Log.i("$TAG_PREFIX/$tag", message)
        }
    }

    /**
     * 警告日志
     */
    fun w(tag: String, message: String) {
        if (logLevel.ordinal <= LogLevel.WARN.ordinal) {
            Log.w("$TAG_PREFIX/$tag", message)
        }
    }

    /**
     * 错误日志
     */
    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (logLevel.ordinal <= LogLevel.ERROR.ordinal) {
            if (throwable != null) {
                Log.e("$TAG_PREFIX/$tag", message, throwable)
            } else {
                Log.e("$TAG_PREFIX/$tag", message)
            }
        }
    }

    /**
     * 格式化日志输出
     */
    fun formatLog(tag: String, format: String, vararg args: Any) {
        try {
            val message = String.format(format, *args)
            d(tag, message)
        } catch (e: Exception) {
            e(tag, "格式化日志失败: $format")
        }
    }

    /**
     * 打印方法调用堆栈
     */
    fun printStackTrace(tag: String, message: String = "Stack trace:") {
        if (isDebugEnabled) {
            Log.d("$TAG_PREFIX/$tag", message)
            val stackTrace = Thread.currentThread().stackTrace
            stackTrace.take(10).forEachIndexed { index, element ->
                Log.d("$TAG_PREFIX/$tag", "  at $element")
            }
        }
    }

    /**
     * 性能日志
     */
    fun performanceLog(tag: String, operation: String, startTime: Long) {
        val elapsed = System.currentTimeMillis() - startTime
        i(tag, "[PERF] $operation took ${elapsed}ms")
    }

    /**
     * 设置日志级别
     */
    fun setLogLevel(level: LogLevel) {
        logLevel = level
        i(TAG_PREFIX, "Log level changed to: $level")
    }

    /**
     * 启用/禁用调试模式
     */
    fun setDebugEnabled(enabled: Boolean) {
        isDebugEnabled = enabled
        i(TAG_PREFIX, "Debug mode: $enabled")
    }
}

/**
 * 扩展函数：快速日志
 */
fun String.logDebug(tag: String = "General") {
    Logger.d(tag, this)
}

fun String.logInfo(tag: String = "General") {
    Logger.i(tag, this)
}

fun String.logError(tag: String = "General", throwable: Throwable? = null) {
    Logger.e(tag, this, throwable)
}
