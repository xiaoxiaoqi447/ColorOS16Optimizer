package com.optimizer.coloros16.hooks

import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 主题定制 Hook
 *
 * 提供以下优化功能：
 * - 解锁主题限制
 * - 图标包支持
 * - 壁纸优化
 * - 主题预览优化
 * - ColorOS 主题定制
 */
class ThemeHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "ThemeHook"

        // 目标类名
        private const val CLASS_THEME_SERVICE = "com.android.server.theme.ThemeService"
        private const val CLASS_THEME_MANAGER = "com.android.server.themes.ThemeManagerService"
        private const val CLASS_ICON_PACK = "android.content.pm.ICON_PACK"
        private const val CLASS_WALLPAPER_MANAGER = "android.app.WallpaperManager"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.thememanager",
            "com.coloros.thememanager",
            "com.android.systemui",
            "com.android.launcher"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册主题定制 Hook...")

        // Hook 主题服务
        hookThemeService()

        // Hook 图标包
        hookIconPack()

        // Hook 壁纸管理
        hookWallpaperManager()

        // Hook 主题检查
        hookThemeValidation()

        enable()
    }

    /**
     * Hook 主题服务
     */
    private fun hookThemeService() {
        try {
            // Hook getAvailableThemes
            XposedHelpers.findAndHookMethod(
                CLASS_THEME_SERVICE,
                null,
                "getAvailableThemes",
                object : XC_MethodHook<Any?>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isUnlockThemes()) {
                            // 解锁所有主题
                            Logger.d(TAG, "解锁主题列表")
                        }
                    }
                }
            )

            // Hook applyTheme
            XposedHelpers.findAndHookMethod(
                CLASS_THEME_SERVICE,
                null,
                "applyTheme",
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val themeId = param.args[0] as String
                        Logger.d(TAG, "应用主题: $themeId")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "主题应用结果: ${param.result}")
                    }
                }
            )

            // Hook isThemeSupported
            XposedHelpers.findAndHookMethod(
                CLASS_THEME_SERVICE,
                null,
                "isThemeSupported",
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isUnlockThemes()) {
                            // 强制返回 true 以解锁主题
                            param.result = true
                            val themeId = param.args[0] as String
                            Logger.d(TAG, "解锁主题检查: $themeId -> true")
                        }
                    }
                }
            )

            Logger.d(TAG, "ThemeService Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook ThemeService 失败: ${e.message}")
        }
    }

    /**
     * Hook 图标包
     */
    private fun hookIconPack() {
        if (!configManager.isIconPackSupport()) {
            Logger.d(TAG, "图标包支持未启用")
            return
        }

        try {
            // Hook getIconPackResources
            XposedHelpers.findAndHookMethod(
                "android.content.pm.IconPackHelper",
                null,
                "getIconPackResources",
                Context::class.java,
                String::class.java,
                object : XC_MethodHook<Any?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val packageName = param.args[1] as String
                        Logger.d(TAG, "获取图标包资源: $packageName")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (param.result == null && configManager.isIconPackSupport()) {
                            Logger.d(TAG, "图标包资源为空，尝试加载")
                        }
                    }
                }
            )

            // Hook isIconPackAvailable
            XposedHelpers.findAndHookMethod(
                "android.content.pm.IconPackHelper",
                null,
                "isIconPackAvailable",
                Context::class.java,
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isIconPackSupport()) {
                            // 强制启用图标包支持
                            param.result = true
                            val packageName = param.args[1] as String
                            Logger.d(TAG, "启用图标包: $packageName")
                        }
                    }
                }
            )

            Logger.d(TAG, "IconPack Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook IconPack 失败: ${e.message}")
        }
    }

    /**
     * Hook 壁纸管理器
     */
    private fun hookWallpaperManager() {
        if (!configManager.isWallpaperOptimization()) {
            Logger.d(TAG, "壁纸优化未启用")
            return
        }

        try {
            // Hook setWallpaper
            XposedHelpers.findAndHookMethod(
                CLASS_WALLPAPER_MANAGER,
                null,
                "setWallpaper",
                android.graphics.Bitmap::class.java,
                object : XC_MethodHook<android.os.ParcelFileDescriptor?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "设置壁纸")
                    }
                }
            )

            // Hook getWallpaperInfo
            XposedHelpers.findAndHookMethod(
                CLASS_WALLPAPER_MANAGER,
                null,
                "getWallpaperInfo",
                object : XC_MethodHook<android.app.WallpaperInfo?>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "获取壁纸信息")
                    }
                }
            )

            // Hook isWallpaperSupported
            XposedHelpers.findAndHookMethod(
                CLASS_WALLPAPER_MANAGER,
                null,
                "isWallpaperSupported",
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "检查壁纸支持")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isWallpaperOptimization() && !(param.result as Boolean)) {
                            // 强制启用壁纸支持
                            param.result = true
                            Logger.d(TAG, "启用壁纸支持")
                        }
                    }
                }
            )

            Logger.d(TAG, "WallpaperManager Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook WallpaperManager 失败: ${e.message}")
        }
    }

    /**
     * Hook 主题验证
     */
    private fun hookThemeValidation() {
        try {
            // Hook validateTheme
            XposedHelpers.findAndHookMethod(
                CLASS_THEME_MANAGER,
                null,
                "validateTheme",
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val themeId = param.args[0] as String
                        Logger.d(TAG, "验证主题: $themeId")

                        if (configManager.isUnlockThemes()) {
                            // 跳过主题验证
                            param.result = true
                        }
                    }
                }
            )

            // Hook checkThemeCompatibility
            XposedHelpers.findAndHookMethod(
                CLASS_THEME_MANAGER,
                null,
                "checkThemeCompatibility",
                String::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isUnlockThemes()) {
                            // 强制通过兼容性检查
                            param.result = true
                            val themeId = param.args[0] as String
                            Logger.d(TAG, "跳过主题兼容性检查: $themeId")
                        }
                    }
                }
            )

            Logger.d(TAG, "ThemeValidation Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook ThemeValidation 失败: ${e.message}")
        }
    }

    /**
     * 是否已解锁所有主题
     */
    fun isThemesUnlocked(): Boolean {
        return configManager.isUnlockThemes()
    }

    /**
     * 是否支持图标包
     */
    fun isIconPackEnabled(): Boolean {
        return configManager.isIconPackSupport()
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "主题定制已启用 - 解锁主题: ${configManager.isUnlockThemes()}, 图标包: ${configManager.isIconPackSupport()}")
    }
}
