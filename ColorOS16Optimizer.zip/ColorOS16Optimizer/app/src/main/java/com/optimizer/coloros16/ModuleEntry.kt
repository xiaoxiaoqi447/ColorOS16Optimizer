package com.optimizer.coloros16

import android.content.Context
import android.util.Log
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.hooks.*
import com.optimizer.coloros16.utils.Logger
import org.lsposed.lsplant.LSPApplication
import org.lsposed.lsplant.callbacks.StyleableCallback
import org.lsposed.lsplant.hook.HookFactory
import org.lsposed.lsplant.hook.HookManager

/**
 * ColorOS 16 优化器 - LSP 模块入口
 *
 * 该模块提供 ColorOS 16 系统的全面优化功能，包括：
 * - 系统动画优化
 * - 电池优化
 * - 网络优化
 * - 主题定制
 * - 状态栏优化
 * - 通知栏优化
 * - 系统设置增强
 * - 隐私增强
 */
@LSPApplication
class ModuleEntry : HookFactory() {

    companion object {
        private const val TAG = "ColorOS16Optimizer"
        private const val MODULE_PACKAGE = "com.optimizer.coloros16"

        // 系统包名
        const val PACKAGE_SYSTEM_UI = "com.android.systemui"
        const val PACKAGE_SETTINGS = "com.android.settings"
        const val PACKAGE_TELEPHONY = "com.android.phone"
        const val PACKAGE_NETWORK = "com.android.net"
        const val PACKAGE_THEMES = "com.android.thememanager"
        const val PACKAGE_POWER = "com.android.internal.os"

        // ColorOS 包名
        const val PACKAGE_COLOROS_SYSTEM = "com.coloros.system"
        const val PACKAGE_COLOROS_SECURITY = "com.coloros.safecenter"
        const val PACKAGE_COLOROS_PERMISSION = "com.coloros.oppoguardelf"

        lateinit var instance: ModuleEntry
            private set

        fun isModuleActive(): Boolean = ::instance.isInitialized
    }

    private lateinit var configManager: ConfigManager
    private val activeHooks = mutableListOf<BaseHook>()

    override fun onLoad() {
        super.onLoad()
        instance = this
        Logger.init()
        Logger.i(TAG, "ColorOS 16 优化器模块加载中...")

        try {
            // 初始化配置管理器
            configManager = ConfigManager.getInstance()

            // 根据配置启用 Hooks
            initHooks()

            Logger.i(TAG, "ColorOS 16 优化器模块加载完成")
        } catch (e: Exception) {
            Logger.e(TAG, "模块加载失败: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun initHooks() {
        Logger.d(TAG, "初始化 Hooks...")

        // 系统动画优化
        if (configManager.isAnimationEnabled()) {
            activeHooks.add(AnimationHook(this))
            Logger.d(TAG, "动画优化 Hook 已启用")
        }

        // 电池优化
        if (configManager.isBatteryEnabled()) {
            activeHooks.add(BatteryHook(this))
            Logger.d(TAG, "电池优化 Hook 已启用")
        }

        // 网络优化
        if (configManager.isNetworkEnabled()) {
            activeHooks.add(NetworkHook(this))
            Logger.d(TAG, "网络优化 Hook 已启用")
        }

        // 主题定制
        if (configManager.isThemeEnabled()) {
            activeHooks.add(ThemeHook(this))
            Logger.d(TAG, "主题定制 Hook 已启用")
        }

        // 状态栏优化
        if (configManager.isStatusBarEnabled()) {
            activeHooks.add(StatusBarHook(this))
            Logger.d(TAG, "状态栏优化 Hook 已启用")
        }

        // 通知栏优化
        if (configManager.isNotificationEnabled()) {
            activeHooks.add(NotificationHook(this))
            Logger.d(TAG, "通知栏优化 Hook 已启用")
        }

        // 系统设置增强
        if (configManager.isSettingsEnabled()) {
            activeHooks.add(SettingsHook(this))
            Logger.d(TAG, "系统设置增强 Hook 已启用")
        }

        // 隐私增强
        if (configManager.isPrivacyEnabled()) {
            activeHooks.add(PrivacyHook(this))
            Logger.d(TAG, "隐私增强 Hook 已启用")
        }

        // 注册所有 Hooks
        activeHooks.forEach { hook ->
            try {
                hook.register()
            } catch (e: Exception) {
                Logger.e(TAG, "注册 Hook 失败: ${hook.javaClass.simpleName}, ${e.message}")
            }
        }

        Logger.i(TAG, "已启用 ${activeHooks.size} 个 Hooks")
    }

    override fun registerHooker() {
        // 注册 Hook 回调
        HookManager.addCallback(object : StyleableCallback() {
            override fun onSystemServerStarted() {
                Logger.d(TAG, "System Server 已启动")
                // 在系统服务启动后应用配置
                applyRuntimeConfigs()
            }
        })
    }

    private fun applyRuntimeConfigs() {
        // 应用运行时配置
        Logger.d(TAG, "应用运行时配置...")

        // 刷新配置
        configManager.refresh()

        // 应用动画配置
        if (configManager.isAnimationEnabled()) {
            applyAnimationConfigs()
        }

        // 应用电池配置
        if (configManager.isBatteryEnabled()) {
            applyBatteryConfigs()
        }
    }

    private fun applyAnimationConfigs() {
        try {
            val scale = configManager.getAnimationSpeed()
            Logger.d(TAG, "设置动画速度: $scale")

            // 设置窗口动画缩放
            android.provider.Settings.Global.putFloat(
                HookManager.getInstance().remoteContext?.contentResolver,
                android.provider.Settings.Global.WINDOW_ANIMATION_SCALE,
                scale
            )

            // 设置过渡动画缩放
            android.provider.Settings.Global.putFloat(
                HookManager.getInstance().remoteContext?.contentResolver,
                android.provider.Settings.Global.TRANSITION_ANIMATION_SCALE,
                scale
            )

            // 设置Animator时长缩放
            android.provider.Settings.Global.putFloat(
                HookManager.getInstance().remoteContext?.contentResolver,
                android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                scale
            )
        } catch (e: Exception) {
            Logger.e(TAG, "应用动画配置失败: ${e.message}")
        }
    }

    private fun applyBatteryConfigs() {
        try {
            val context = HookManager.getInstance().remoteContext ?: return

            // 优化后台进程
            val maxBackground = configManager.getBackgroundLimit()
            Logger.d(TAG, "设置后台进程限制: $maxBackground")

        } catch (e: Exception) {
            Logger.e(TAG, "应用电池配置失败: ${e.message}")
        }
    }

    fun getConfigManager(): ConfigManager = configManager

    fun isHookEnabled(hookType: HookType): Boolean {
        return when (hookType) {
            HookType.ANIMATION -> configManager.isAnimationEnabled()
            HookType.BATTERY -> configManager.isBatteryEnabled()
            HookType.NETWORK -> configManager.isNetworkEnabled()
            HookType.THEME -> configManager.isThemeEnabled()
            HookType.STATUS_BAR -> configManager.isStatusBarEnabled()
            HookType.NOTIFICATION -> configManager.isNotificationEnabled()
            HookType.SETTINGS -> configManager.isSettingsEnabled()
            HookType.PRIVACY -> configManager.isPrivacyEnabled()
        }
    }

    enum class HookType {
        ANIMATION,
        BATTERY,
        NETWORK,
        THEME,
        STATUS_BAR,
        NOTIFICATION,
        SETTINGS,
        PRIVACY
    }
}
