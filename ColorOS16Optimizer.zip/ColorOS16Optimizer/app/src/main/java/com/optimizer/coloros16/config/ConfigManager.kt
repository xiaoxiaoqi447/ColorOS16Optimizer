package com.optimizer.coloros16.config

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

/**
 * 配置管理器
 *
 * 负责管理模块的所有配置项
 * 支持 SharedPreferences 和 DataStore 两种存储方式
 */
class ConfigManager private constructor() {

    companion object {
        private const val TAG = "ConfigManager"
        private const val PREFS_NAME = "coloros16_optimizer_prefs"
        private const val DATASTORE_NAME = "coloros16_optimizer_datastore"

        // 配置键名
        private object Keys {
            // 模块总开关
            const val MODULE_ENABLED = "module_enabled"

            // 动画优化
            const val ANIMATION_ENABLED = "animation_enabled"
            const val ANIMATION_SPEED = "animation_speed"
            const val WINDOW_ANIMATION_SCALE = "window_animation_scale"
            const val TRANSITION_ANIMATION_SCALE = "transition_animation_scale"
            const val ANIMATOR_DURATION_SCALE = "animator_duration_scale"
            const val DISABLE_ANIMATION = "disable_animation"

            // 电池优化
            const val BATTERY_ENABLED = "battery_enabled"
            const val BACKGROUND_LIMIT = "background_limit"
            const val BATTERY_SAVER_ENHANCED = "battery_saver_enhanced"
            const val BLOCK_WAKELOCK = "block_wakelock"

            // 网络优化
            const val NETWORK_ENABLED = "network_enabled"
            const val DNS_OPTIMIZATION = "dns_optimization"
            const val TCP_OPTIMIZATION = "tcp_optimization"
            const val IPV6_OPTIMIZATION = "ipv6_optimization"

            // 主题定制
            const val THEME_ENABLED = "theme_enabled"
            const val UNLOCK_THEMES = "unlock_themes"
            const val ICON_PACK_SUPPORT = "icon_pack_support"
            const val WALLPAPER_OPTIMIZATION = "wallpaper_optimization"

            // 状态栏优化
            const val STATUSBAR_ENABLED = "statusbar_enabled"
            const val SHOW_NETWORK_SPEED = "show_network_speed"
            const val BATTERY_PERCENTAGE = "battery_percentage"
            const val CLOCK_FORMAT = "clock_format"

            // 通知栏优化
            const val NOTIFICATION_ENABLED = "notification_enabled"
            const val NOTIFICATION_GROUPING = "notification_grouping"
            const val NOTIFICATION_HISTORY = "notification_history"
            const val NOTIFICATION_SOUND = "notification_sound"

            // 系统设置
            const val SETTINGS_ENABLED = "settings_enabled"
            const val SHOW_HIDDEN_SETTINGS = "show_hidden_settings"
            const val DEVELOPER_OPTIONS = "developer_options"
            const val BACKUP_OPTIMIZATION = "backup_optimization"

            // 隐私增强
            const val PRIVACY_ENABLED = "privacy_enabled"
            const val PERMISSION_MANAGEMENT = "permission_management"
            const val TRACKING_PROTECTION = "tracking_protection"
            const val MICROPHONE_PROTECTION = "microphone_protection"
        }

        @Volatile
        private var instance: ConfigManager? = null

        fun getInstance(): ConfigManager {
            return instance ?: synchronized(this) {
                instance ?: ConfigManager().also { instance = it }
            }
        }
    }

    private lateinit var prefs: SharedPreferences
    private var context: Context? = null

    fun init(context: Context) {
        this.context = context.applicationContext
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        Log.d(TAG, "配置管理器初始化完成")
    }

    fun refresh() {
        Log.d(TAG, "刷新配置")
    }

    // ==================== 模块总开关 ====================

    fun isModuleEnabled(): Boolean = prefs.getBoolean(Keys.MODULE_ENABLED, true)

    fun setModuleEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.MODULE_ENABLED, enabled).apply()
    }

    // ==================== 动画优化 ====================

    fun isAnimationEnabled(): Boolean = prefs.getBoolean(Keys.ANIMATION_ENABLED, true)

    fun setAnimationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.ANIMATION_ENABLED, enabled).apply()
    }

    fun getAnimationSpeed(): Float {
        val speed = prefs.getFloat(Keys.ANIMATION_SPEED, 1.0f)
        return if (prefs.getBoolean(Keys.DISABLE_ANIMATION, false)) 0f else speed
    }

    fun setAnimationSpeed(speed: Float) {
        prefs.edit().putFloat(Keys.ANIMATION_SPEED, speed).apply()
    }

    fun setWindowAnimationScale(scale: Float) {
        prefs.edit().putFloat(Keys.WINDOW_ANIMATION_SCALE, scale).apply()
    }

    fun getWindowAnimationScale(): Float = prefs.getFloat(Keys.WINDOW_ANIMATION_SCALE, 1.0f)

    fun setTransitionAnimationScale(scale: Float) {
        prefs.edit().putFloat(Keys.TRANSITION_ANIMATION_SCALE, scale).apply()
    }

    fun getTransitionAnimationScale(): Float = prefs.getFloat(Keys.TRANSITION_ANIMATION_SCALE, 1.0f)

    fun setAnimatorDurationScale(scale: Float) {
        prefs.edit().putFloat(Keys.ANIMATOR_DURATION_SCALE, scale).apply()
    }

    fun getAnimatorDurationScale(): Float = prefs.getFloat(Keys.ANIMATOR_DURATION_SCALE, 1.0f)

    fun isAnimationDisabled(): Boolean = prefs.getBoolean(Keys.DISABLE_ANIMATION, false)

    fun setDisableAnimation(disable: Boolean) {
        prefs.edit().putBoolean(Keys.DISABLE_ANIMATION, disable).apply()
    }

    // ==================== 电池优化 ====================

    fun isBatteryEnabled(): Boolean = prefs.getBoolean(Keys.BATTERY_ENABLED, true)

    fun setBatteryEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.BATTERY_ENABLED, enabled).apply()
    }

    fun getBackgroundLimit(): Int = prefs.getInt(Keys.BACKGROUND_LIMIT, 4)

    fun setBackgroundLimit(limit: Int) {
        prefs.edit().putInt(Keys.BACKGROUND_LIMIT, limit).apply()
    }

    fun isBatterySaverEnhanced(): Boolean = prefs.getBoolean(Keys.BATTERY_SAVER_ENHANCED, true)

    fun setBatterySaverEnhanced(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.BATTERY_SAVER_ENHANCED, enabled).apply()
    }

    fun isBlockWakelock(): Boolean = prefs.getBoolean(Keys.BLOCK_WAKELOCK, false)

    fun setBlockWakelock(block: Boolean) {
        prefs.edit().putBoolean(Keys.BLOCK_WAKELOCK, block).apply()
    }

    // ==================== 网络优化 ====================

    fun isNetworkEnabled(): Boolean = prefs.getBoolean(Keys.NETWORK_ENABLED, true)

    fun setNetworkEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.NETWORK_ENABLED, enabled).apply()
    }

    fun isDnsOptimization(): Boolean = prefs.getBoolean(Keys.DNS_OPTIMIZATION, true)

    fun setDnsOptimization(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.DNS_OPTIMIZATION, enabled).apply()
    }

    fun isTcpOptimization(): Boolean = prefs.getBoolean(Keys.TCP_OPTIMIZATION, true)

    fun setTcpOptimization(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.TCP_OPTIMIZATION, enabled).apply()
    }

    fun isIpv6Optimization(): Boolean = prefs.getBoolean(Keys.IPV6_OPTIMIZATION, true)

    fun setIpv6Optimization(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.IPV6_OPTIMIZATION, enabled).apply()
    }

    // ==================== 主题定制 ====================

    fun isThemeEnabled(): Boolean = prefs.getBoolean(Keys.THEME_ENABLED, true)

    fun setThemeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.THEME_ENABLED, enabled).apply()
    }

    fun isUnlockThemes(): Boolean = prefs.getBoolean(Keys.UNLOCK_THEMES, true)

    fun setUnlockThemes(unlock: Boolean) {
        prefs.edit().putBoolean(Keys.UNLOCK_THEMES, unlock).apply()
    }

    fun isIconPackSupport(): Boolean = prefs.getBoolean(Keys.ICON_PACK_SUPPORT, true)

    fun setIconPackSupport(support: Boolean) {
        prefs.edit().putBoolean(Keys.ICON_PACK_SUPPORT, support).apply()
    }

    fun isWallpaperOptimization(): Boolean = prefs.getBoolean(Keys.WALLPAPER_OPTIMIZATION, true)

    fun setWallpaperOptimization(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.WALLPAPER_OPTIMIZATION, enabled).apply()
    }

    // ==================== 状态栏优化 ====================

    fun isStatusBarEnabled(): Boolean = prefs.getBoolean(Keys.STATUSBAR_ENABLED, true)

    fun setStatusBarEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.STATUSBAR_ENABLED, enabled).apply()
    }

    fun isShowNetworkSpeed(): Boolean = prefs.getBoolean(Keys.SHOW_NETWORK_SPEED, false)

    fun setShowNetworkSpeed(show: Boolean) {
        prefs.edit().putBoolean(Keys.SHOW_NETWORK_SPEED, show).apply()
    }

    fun isBatteryPercentage(): Boolean = prefs.getBoolean(Keys.BATTERY_PERCENTAGE, true)

    fun setBatteryPercentage(show: Boolean) {
        prefs.edit().putBoolean(Keys.BATTERY_PERCENTAGE, show).apply()
    }

    fun getClockFormat(): String = prefs.getString(Keys.CLOCK_FORMAT, "HH:mm") ?: "HH:mm"

    fun setClockFormat(format: String) {
        prefs.edit().putString(Keys.CLOCK_FORMAT, format).apply()
    }

    // ==================== 通知栏优化 ====================

    fun isNotificationEnabled(): Boolean = prefs.getBoolean(Keys.NOTIFICATION_ENABLED, true)

    fun setNotificationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.NOTIFICATION_ENABLED, enabled).apply()
    }

    fun isNotificationGrouping(): Boolean = prefs.getBoolean(Keys.NOTIFICATION_GROUPING, true)

    fun setNotificationGrouping(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.NOTIFICATION_GROUPING, enabled).apply()
    }

    fun isNotificationHistory(): Boolean = prefs.getBoolean(Keys.NOTIFICATION_HISTORY, false)

    fun setNotificationHistory(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.NOTIFICATION_HISTORY, enabled).apply()
    }

    fun isNotificationSound(): Boolean = prefs.getBoolean(Keys.NOTIFICATION_SOUND, true)

    fun setNotificationSound(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.NOTIFICATION_SOUND, enabled).apply()
    }

    // ==================== 系统设置 ====================

    fun isSettingsEnabled(): Boolean = prefs.getBoolean(Keys.SETTINGS_ENABLED, true)

    fun setSettingsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.SETTINGS_ENABLED, enabled).apply()
    }

    fun isShowHiddenSettings(): Boolean = prefs.getBoolean(Keys.SHOW_HIDDEN_SETTINGS, true)

    fun setShowHiddenSettings(show: Boolean) {
        prefs.edit().putBoolean(Keys.SHOW_HIDDEN_SETTINGS, show).apply()
    }

    fun isDeveloperOptions(): Boolean = prefs.getBoolean(Keys.DEVELOPER_OPTIONS, true)

    fun setDeveloperOptions(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.DEVELOPER_OPTIONS, enabled).apply()
    }

    fun isBackupOptimization(): Boolean = prefs.getBoolean(Keys.BACKUP_OPTIMIZATION, true)

    fun setBackupOptimization(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.BACKUP_OPTIMIZATION, enabled).apply()
    }

    // ==================== 隐私增强 ====================

    fun isPrivacyEnabled(): Boolean = prefs.getBoolean(Keys.PRIVACY_ENABLED, true)

    fun setPrivacyEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.PRIVACY_ENABLED, enabled).apply()
    }

    fun isPermissionManagement(): Boolean = prefs.getBoolean(Keys.PERMISSION_MANAGEMENT, true)

    fun setPermissionManagement(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.PERMISSION_MANAGEMENT, enabled).apply()
    }

    fun isTrackingProtection(): Boolean = prefs.getBoolean(Keys.TRACKING_PROTECTION, true)

    fun setTrackingProtection(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.TRACKING_PROTECTION, enabled).apply()
    }

    fun isMicrophoneProtection(): Boolean = prefs.getBoolean(Keys.MICROPHONE_PROTECTION, true)

    fun setMicrophoneProtection(enabled: Boolean) {
        prefs.edit().putBoolean(Keys.MICROPHONE_PROTECTION, enabled).apply()
    }

    // ==================== 批量操作 ====================

    /**
     * 重置所有配置为默认值
     */
    fun resetAll() {
        prefs.edit().clear().apply()
        Log.i(TAG, "所有配置已重置")
    }

    /**
     * 获取所有配置
     */
    fun getAllConfigs(): Map<String, Any?> {
        return mapOf(
            "module_enabled" to isModuleEnabled(),
            "animation_enabled" to isAnimationEnabled(),
            "animation_speed" to getAnimationSpeed(),
            "battery_enabled" to isBatteryEnabled(),
            "background_limit" to getBackgroundLimit(),
            "network_enabled" to isNetworkEnabled(),
            "dns_optimization" to isDnsOptimization(),
            "theme_enabled" to isThemeEnabled(),
            "unlock_themes" to isUnlockThemes(),
            "statusbar_enabled" to isStatusBarEnabled(),
            "show_network_speed" to isShowNetworkSpeed(),
            "notification_enabled" to isNotificationEnabled(),
            "notification_grouping" to isNotificationGrouping(),
            "settings_enabled" to isSettingsEnabled(),
            "show_hidden_settings" to isShowHiddenSettings(),
            "privacy_enabled" to isPrivacyEnabled(),
            "tracking_protection" to isTrackingProtection()
        )
    }

    /**
     * 导出配置
     */
    fun exportConfig(): String {
        val configs = getAllConfigs()
        return configs.entries.joinToString("\n") { "${it.key}=${it.value}" }
    }

    /**
     * 导入配置
     */
    fun importConfig(configString: String) {
        try {
            val editor = prefs.edit()
            configString.lines().forEach { line ->
                val parts = line.split("=")
                if (parts.size == 2) {
                    val key = parts[0].trim()
                    val value = parts[1].trim()
                    when (value) {
                        "true" -> editor.putBoolean(key, true)
                        "false" -> editor.putBoolean(key, false)
                        else -> {
                            value.toIntOrNull()?.let { editor.putInt(key, it) }
                            value.toFloatOrNull()?.let { editor.putFloat(key, it) }
                            value.toLongOrNull()?.let { editor.putLong(key, it) }
                            editor.putString(key, value)
                        }
                    }
                }
            }
            editor.apply()
            Log.i(TAG, "配置导入成功")
        } catch (e: Exception) {
            Log.e(TAG, "配置导入失败: ${e.message}")
        }
    }
}
