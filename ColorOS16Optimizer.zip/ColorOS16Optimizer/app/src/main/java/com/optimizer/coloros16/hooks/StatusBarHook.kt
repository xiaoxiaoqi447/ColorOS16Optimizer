package com.optimizer.coloros16.hooks

import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 状态栏优化 Hook
 *
 * 提供以下优化功能：
 * - 显示实时网速
 * - 显示精确电池百分比
 * - 自定义时钟格式
 * - 状态栏布局优化
 * - ColorOS 状态栏定制
 */
class StatusBarHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "StatusBarHook"

        // 目标类名
        private const val CLASS_STATUS_BAR = "com.android.systemui.statusbar.StatusBar"
        private const val CLASS_PHONE_STATUS_BAR = "com.android.systemui.statusbar.phone.PhoneStatusBar"
        private const val CLASS_NOTIFICATION_LIGHTS = "com.android.systemui.statusbar.NotificationLightsView"
        private const val CLASS_STATUS_BAR_ICON = "com.android.systemui.statusbar.StatusBarIcon"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.systemui",
            "com.coloros.systemui"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册状态栏优化 Hook...")

        // Hook 状态栏
        hookStatusBar()

        // Hook 电池视图
        hookBatteryView()

        // Hook 时钟视图
        hookClockView()

        // Hook 网络速度视图
        hookNetworkSpeedView()

        enable()
    }

    /**
     * Hook 状态栏
     */
    private fun hookStatusBar() {
        try {
            // Hook onNotificationPosted
            XposedHelpers.findAndHookMethod(
                CLASS_STATUS_BAR,
                null,
                "onNotificationPosted",
                "com.android.statusbar.notification.NotificationVisibility".loadClass(),
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "通知已发布到状态栏")
                    }
                }
            )

            // Hook updateNotifications
            XposedHelpers.findAndHookMethod(
                CLASS_STATUS_BAR,
                null,
                "updateNotifications",
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "更新通知")
                    }
                }
            )

            // Hook shouldFilterOut
            XposedHelpers.findAndHookMethod(
                CLASS_STATUS_BAR,
                null,
                "shouldFilterOut",
                "com.android.statusbar.notification.NotificationRecord".loadClass(),
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 可以根据配置过滤通知
                        Logger.d(TAG, "检查通知过滤")
                    }
                }
            )

            Logger.d(TAG, "StatusBar Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook StatusBar 失败: ${e.message}")
        }
    }

    /**
     * Hook 电池视图
     */
    private fun hookBatteryView() {
        if (!configManager.isBatteryPercentage()) {
            Logger.d(TAG, "电池百分比显示未启用")
            return
        }

        try {
            // Hook BatteryController
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.BatteryController",
                null,
                "getBatteryLevel",
                object : XC_MethodHook<Int>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val level = param.result as Int
                        Logger.d(TAG, "电池电量: $level%")

                        // 可以在这里修改电池百分比显示逻辑
                    }
                }
            )

            // Hook updateBatteryLevel
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.BatteryController",
                null,
                "updateBatteryLevel",
                Int::class.javaPrimitiveType,
                Boolean::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val level = param.args[0] as Int
                        val isCharging = param.args[1] as Boolean
                        Logger.d(TAG, "更新电池: $level%, 充电: $isCharging")
                    }
                }
            )

            // Hook shouldShowBatteryLevel
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.BatteryController",
                null,
                "shouldShowBatteryLevel",
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 强制显示电池百分比
                        if (configManager.isBatteryPercentage()) {
                            param.result = true
                            Logger.d(TAG, "强制显示电池百分比")
                        }
                    }
                }
            )

            // Hook formatBatteryLevel
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.BatteryController",
                null,
                "formatBatteryLevel",
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<String>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val level = param.args[0] as Int
                        // 可以自定义电池百分比格式
                        val customFormat = "$level%"
                        param.result = customFormat
                        Logger.d(TAG, "电池百分比格式: $customFormat")
                    }
                }
            )

            Logger.d(TAG, "BatteryView Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook BatteryView 失败: ${e.message}")
        }
    }

    /**
     * Hook 时钟视图
     */
    private fun hookClockView() {
        try {
            // Hook Clock
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.Clock",
                null,
                "getSmallTime",
                object : XC_MethodHook<String>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val format = configManager.getClockFormat()
                        Logger.d(TAG, "时钟格式: $format")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val defaultTime = param.result as String
                        val customFormat = configManager.getClockFormat()

                        // 应用自定义格式
                        if (customFormat != "HH:mm") {
                            Logger.d(TAG, "时钟格式化: $defaultTime -> $customFormat")
                            // param.result = customTime
                        }
                    }
                }
            )

            // Hook updateClock
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.Clock",
                null,
                "updateClock",
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "更新时钟")
                    }
                }
            )

            // Hook getFormat
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.policy.Clock",
                null,
                "getFormat",
                object : XC_MethodHook<String>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val customFormat = configManager.getClockFormat()
                        param.result = customFormat
                        Logger.d(TAG, "获取时钟格式: $customFormat")
                    }
                }
            )

            Logger.d(TAG, "ClockView Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook ClockView 失败: ${e.message}")
        }
    }

    /**
     * Hook 网络速度视图
     */
    private fun hookNetworkSpeedView() {
        if (!configManager.isShowNetworkSpeed()) {
            Logger.d(TAG, "网络速度显示未启用")
            return
        }

        try {
            // Hook NetworkController
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.NetworkController",
                null,
                "getNetworkSpeed",
                object : XC_MethodHook<String>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "获取网络速度")
                    }
                }
            )

            // Hook updateNetworkSpeed
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.NetworkController",
                null,
                "updateNetworkSpeed",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val downloadSpeed = param.args[0] as Int
                        val uploadSpeed = param.args[1] as Int
                        Logger.d(TAG, "网络速度: 下载 $downloadSpeed KB/s, 上传 $uploadSpeed KB/s")
                    }
                }
            )

            // Hook shouldShowNetworkSpeed
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.NetworkController",
                null,
                "shouldShowNetworkSpeed",
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isShowNetworkSpeed()) {
                            param.result = true
                            Logger.d(TAG, "启用网络速度显示")
                        }
                    }
                }
            )

            Logger.d(TAG, "NetworkSpeedView Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NetworkSpeedView 失败: ${e.message}")
        }
    }

    /**
     * 是否显示电池百分比
     */
    fun isBatteryPercentageEnabled(): Boolean {
        return configManager.isBatteryPercentage()
    }

    /**
     * 是否显示网络速度
     */
    fun isNetworkSpeedEnabled(): Boolean {
        return configManager.isShowNetworkSpeed()
    }

    /**
     * 获取时钟格式
     */
    fun getClockFormat(): String {
        return configManager.getClockFormat()
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "状态栏优化已启用 - 电池百分比: ${configManager.isBatteryPercentage()}, 网速: ${configManager.isShowNetworkSpeed()}")
    }
}
