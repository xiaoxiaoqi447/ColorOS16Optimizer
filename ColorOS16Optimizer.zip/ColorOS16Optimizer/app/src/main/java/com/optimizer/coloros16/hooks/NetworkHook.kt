package com.optimizer.coloros16.hooks

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.net.InetAddress
import java.net.NetworkInterface

/**
 * 网络优化 Hook
 *
 * 提供以下优化功能：
 * - DNS 优化
 * - TCP 连接优化
 * - IPv6 优化
 * - 网络接口优化
 * - Wi-Fi 优化
 */
class NetworkHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "NetworkHook"

        // DNS 服务器
        private val GOOGLE_DNS = arrayOf("8.8.8.8", "8.8.4.4")
        private val CLOUDLARE_DNS = arrayOf("1.1.1.1", "1.0.0.1")
        private val ALI_DNS = arrayOf("223.5.5.5", "223.6.6.6")

        // TCP 参数
        private const val TCP_BUFFER_SIZE = 262144
        private const val TCP_WINDOW_SIZE = 262144

        // 目标类名
        private const val CLASS_NETWORK_MANAGEMENT_SERVICE = "com.android.server.NetworkManagementService"
        private const val CLASS_CONNECTIVITY_SERVICE = "com.android.server.ConnectivityService"
        private const val CLASS_DNS = "android.net.NetworkProperties"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.network",
            "com.android.net",
            "com.android.systemui",
            "com.android.settings"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册网络优化 Hook...")

        // Hook DNS
        hookDns()

        // Hook Network Management
        hookNetworkManagement()

        // Hook Connectivity
        hookConnectivity()

        // Hook Network Interface
        hookNetworkInterface()

        enable()
    }

    /**
     * Hook DNS 相关
     */
    private fun hookDns() {
        if (!configManager.isDnsOptimization()) {
            Logger.d(TAG, "DNS 优化未启用")
            return
        }

        try {
            // Hook NetworkProperties.buildDnsProperties
            XposedHelpers.findAndHookMethod(
                "android.net.NetworkProperties",
                null,
                "buildDnsProperties",
                String::class.java,
                Array<String>::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val dnsServers = param.args[1] as Array<String>
                        Logger.d(TAG, "DNS 服务器: ${dnsServers.joinToString()}")

                        // 可以替换为优化的 DNS
                        // param.args[1] = ALI_DNS
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        // 修改返回的 DNS 配置
                    }
                }
            )

            // Hook InetAddress.all_by_name
            XposedHelpers.findAndHookMethod(
                InetAddress::class.java,
                "allByName",
                String::class.java,
                object : XC_MethodHook<Array<InetAddress>>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val hostname = param.args[0] as String
                        Logger.d(TAG, "DNS 查询: $hostname")
                    }
                }
            )

            // Hook DNS lookup
            XposedHelpers.findAndHookMethod(
                InetAddress::class.java,
                "getAllByName",
                String::class.java,
                object : XC_MethodHook<Array<InetAddress>>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val hostname = param.args[0] as String
                        Logger.d(TAG, "DNS 解析: $hostname")
                    }
                }
            )

            Logger.d(TAG, "DNS Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook DNS 失败: ${e.message}")
        }
    }

    /**
     * Hook 网络管理服务
     */
    private fun hookNetworkManagement() {
        try {
            // Hook setInterfaceThrottle
            XposedHelpers.findAndHookMethod(
                CLASS_NETWORK_MANAGEMENT_SERVICE,
                null,
                "setInterfaceThrottle",
                String::class.java,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val iface = param.args[0] as String
                        val rxKbps = param.args[1] as Int
                        val txKbps = param.args[2] as Int

                        Logger.d(TAG, "设置接口限速: $iface, RX: ${rxKbps}Kbps, TX: ${txKbps}Kbps")

                        // 移除限速以优化网络
                        // param.result = null
                    }
                }
            )

            // Hook enableNetD
            XposedHelpers.findAndHookMethod(
                CLASS_NETWORK_MANAGEMENT_SERVICE,
                null,
                "isNetDReady",
                object : XC_MethodHook<Boolean>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "NetD 服务状态: ${param.result}")
                    }
                }
            )

            Logger.d(TAG, "NetworkManagement Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NetworkManagement 失败: ${e.message}")
        }
    }

    /**
     * Hook 连接性服务
     */
    private fun hookConnectivity() {
        try {
            // Hook getActiveNetworkInfo
            XposedHelpers.findAndHookMethod(
                CLASS_CONNECTIVITY_SERVICE,
                null,
                "getActiveNetworkInfo",
                object : XC_MethodHook<Any?>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val networkInfo = param.result
                        if (networkInfo != null) {
                            Logger.d(TAG, "当前网络: ${XposedHelpers.callMethod(networkInfo, "getTypeName")}")
                        }
                    }
                }
            )

            // Hook getNetworkInfo
            XposedHelpers.findAndHookMethod(
                CLASS_CONNECTIVITY_SERVICE,
                null,
                "getNetworkInfo",
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val networkType = param.args[0] as Int
                        Logger.d(TAG, "获取网络信息: type=$networkType")
                    }
                }
            )

            // Hook registerNetworkCallback
            XposedHelpers.findAndHookMethod(
                CLASS_CONNECTIVITY_SERVICE,
                null,
                "registerNetworkCallback",
                android.net.NetworkRequest::class.java,
                android.app.ActivityThread::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "注册网络回调")
                    }
                }
            )

            Logger.d(TAG, "Connectivity Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook Connectivity 失败: ${e.message}")
        }
    }

    /**
     * Hook 网络接口
     */
    private fun hookNetworkInterface() {
        try {
            // Hook NetworkInterface.getByName
            XposedHelpers.findAndHookMethod(
                NetworkInterface::class.java,
                "getByName",
                String::class.java,
                object : XC_MethodHook<NetworkInterface?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val name = param.args[0] as String
                        Logger.d(TAG, "获取网络接口: $name")
                    }
                }
            )

            // Hook getNetworkInterfaces
            XposedHelpers.findAndHookMethod(
                NetworkInterface::class.java,
                "getNetworkInterfaces",
                object : XC_MethodHook<java.util.Enumeration<NetworkInterface>>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "获取所有网络接口")
                    }
                }
            )

            Logger.d(TAG, "NetworkInterface Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NetworkInterface 失败: ${e.message}")
        }
    }

    /**
     * 获取当前 DNS 配置
     */
    fun getCurrentDnsServers(): List<String> {
        return try {
            val dnsProp = XposedHelpers.callStaticMethod(
                XposedHelpers.findClass("android.os.SystemProperties", null),
                "get",
                "net.dns1"
            ) as String
            listOf(dnsProp)
        } catch (e: Exception) {
            Logger.e(TAG, "获取 DNS 配置失败: ${e.message}")
            emptyList()
        }
    }

    /**
     * 是否启用了 TCP 优化
     */
    fun isTcpOptimizationEnabled(): Boolean {
        return configManager.isTcpOptimization()
    }

    /**
     * 是否启用了 IPv6 优化
     */
    fun isIpv6OptimizationEnabled(): Boolean {
        return configManager.isIpv6Optimization()
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "网络优化已启用 - DNS: ${configManager.isDnsOptimization()}, TCP: ${configManager.isTcpOptimization()}")
    }
}
