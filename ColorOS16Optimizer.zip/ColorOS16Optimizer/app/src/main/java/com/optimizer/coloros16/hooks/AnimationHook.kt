package com.optimizer.coloros16.hooks

import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 系统动画优化 Hook
 *
 * 提供以下优化功能：
 * - 窗口动画缩放调整
 * - 过渡动画缩放调整
 * - Animator 时长缩放调整
 * - 全面禁用动画选项
 * - ColorOS 特有动画优化
 */
class AnimationHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "AnimationHook"

        // 动画缩放值
        private const val SCALE_0X = 0.0f      // 完全禁用
        private const val SCALE_0_5X = 0.5f    // 0.5倍
        private const val SCALE_1X = 1.0f      // 默认
        private const val SCALE_1_5X = 1.5f    // 1.5倍
        private const val SCALE_2X = 2.0f      // 2倍

        // 目标类名
        private const val CLASS_WINDOW_MANAGER_SERVICE = "com.android.server.wm.WindowManagerService"
        private const val CLASS_ACTIVITY_TASK_MANAGER = "com.android.server.wm.ActivityTaskManagerService"
        private const val CLASS_DISPLAY_CONTENT = "com.android.server.wm.DisplayContent"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.systemui",
            "com.android.launcher",
            "com.coloros.launcher",
            "com.android.settings"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册动画优化 Hook...")

        // Hook WindowManagerService
        hookWindowManagerService()

        // Hook ActivityTaskManager
        hookActivityTaskManager()

        // Hook System Properties
        hookSystemProperties()

        // Hook Animation Classes
        hookAnimationClasses()

        enable()
    }

    /**
     * Hook WindowManagerService
     */
    private fun hookWindowManagerService() {
        try {
            XposedHelpers.findAndHookMethod(
                CLASS_WINDOW_MANAGER_SERVICE,
                null,
                "getWindowAnimationScaleLocked",
                object : XC_MethodHook<Long>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val scale = configManager.getWindowAnimationScale()
                        Logger.d(TAG, "Window 动画缩放: $scale")
                        // 返回自定义缩放值
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val scale = configManager.getWindowAnimationScale()
                        if (scale != SCALE_1X) {
                            param.result = (scale * 1000).toLong()
                        }
                    }
                }
            )

            Logger.d(TAG, "WindowManagerService Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook WindowManagerService 失败: ${e.message}")
        }
    }

    /**
     * Hook ActivityTaskManagerService
     */
    private fun hookActivityTaskManager() {
        try {
            XposedHelpers.findAndHookMethod(
                CLASS_ACTIVITY_TASK_MANAGER,
                null,
                "getTransitionAnimationScaleLocked",
                object : XC_MethodHook<Long>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val scale = configManager.getTransitionAnimationScale()
                        Logger.d(TAG, "过渡动画缩放: $scale")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val scale = configManager.getTransitionAnimationScale()
                        if (scale != SCALE_1X) {
                            param.result = (scale * 1000).toLong()
                        }
                    }
                }
            )

            Logger.d(TAG, "ActivityTaskManagerService Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook ActivityTaskManagerService 失败: ${e.message}")
        }
    }

    /**
     * Hook 系统属性
     */
    private fun hookSystemProperties() {
        try {
            // Hook Settings.Global.WINDOW_ANIMATION_SCALE
            XposedHelpers.findAndHookMethod(
                "android.provider.Settings\$Global",
                null,
                "getFloat",
                android.content.ContentResolver::class.java,
                String::class.java,
                Float::class.javaPrimitiveType,
                object : XC_MethodHook<Float>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val name = param.args[1] as String
                        if (name == Settings.Global.WINDOW_ANIMATION_SCALE) {
                            val scale = configManager.getWindowAnimationScale()
                            param.result = scale
                            Logger.d(TAG, "Settings.Global WINDOW_ANIMATION_SCALE: $scale")
                        } else if (name == Settings.Global.TRANSITION_ANIMATION_SCALE) {
                            val scale = configManager.getTransitionAnimationScale()
                            param.result = scale
                            Logger.d(TAG, "Settings.Global TRANSITION_ANIMATION_SCALE: $scale")
                        } else if (name == Settings.Global.ANIMATOR_DURATION_SCALE) {
                            val scale = configManager.getAnimatorDurationScale()
                            param.result = scale
                            Logger.d(TAG, "Settings.Global ANIMATOR_DURATION_SCALE: $scale")
                        }
                    }
                }
            )

            Logger.d(TAG, "System Properties Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook System Properties 失败: ${e.message}")
        }
    }

    /**
     * Hook 动画相关类
     */
    private fun hookAnimationClasses() {
        try {
            // Hook PhoneWindowManager for ColorOS
            XposedHelpers.findAndHookMethod(
                "com.android.internal.policy.PhoneWindowManager",
                null,
                "getMaxAnimationDuration",
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Int>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val defaultDuration = param.result as Int
                        val scale = configManager.getAnimationSpeed()
                        val newDuration = (defaultDuration * scale).toInt()
                        param.result = newDuration
                        Logger.d(TAG, "Max Animation Duration: $defaultDuration -> $newDuration")
                    }
                }
            )

            // Hook WindowContainer for animation duration
            XposedHelpers.findAndHookMethod(
                CLASS_DISPLAY_CONTENT,
                null,
                "getAnimationDurationScale",
                object : XC_MethodHook<Float>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val scale = configManager.getAnimationSpeed()
                        param.result = scale
                    }
                }
            )

            Logger.d(TAG, "Animation Classes Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook Animation Classes 失败: ${e.message}")
        }
    }

    /**
     * 获取推荐的动画缩放值
     */
    fun getRecommendedScale(): Float {
        return when {
            configManager.isAnimationDisabled() -> SCALE_0X
            else -> configManager.getAnimationSpeed()
        }
    }

    /**
     * 获取预设动画速度名称
     */
    fun getAnimationPresetName(): String {
        return when (getRecommendedScale()) {
            SCALE_0X -> "完全禁用"
            SCALE_0_5X -> "快速 (0.5x)"
            SCALE_1X -> "默认 (1x)"
            SCALE_1_5X -> "较慢 (1.5x)"
            SCALE_2X -> "最慢 (2x)"
            else -> "自定义"
        }
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "动画优化已启用 - ${getAnimationPresetName()}")
    }
}
