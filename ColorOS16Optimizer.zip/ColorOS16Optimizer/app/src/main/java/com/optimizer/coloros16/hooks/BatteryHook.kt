package com.optimizer.coloros16.hooks

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 电池优化 Hook
 *
 * 提供以下优化功能：
 * - 后台进程限制
 * - 省电模式增强
 * - 唤醒锁管理
 * - 应用功耗监控
 * - ColorOS 电池优化
 */
class BatteryHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "BatteryHook"

        // 后台限制级别
        const val BACKGROUND_LIMIT_NONE = 0
        const val BACKGROUND_LIMIT_MODERATE = 3
        const val BACKGROUND_LIMIT_RESTRICTED = 4
        const val BACKGROUND_LIMIT_GHOST = 5

        // 目标类名
        private const val CLASS_ACTIVITY_MANAGER_SERVICE = "com.android.server.am.ActivityManagerService"
        private const val CLASS_BATTERY_SERVICE = "com.android.server.BatteryService"
        private const val CLASS_POWER_MANAGER_SERVICE = "com.android.server.power.PowerManagerService"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.systemui",
            "com.android.settings",
            "com.coloros.oppoguardelf",
            "com.coloros.system"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册电池优化 Hook...")

        // Hook ActivityManagerService
        hookActivityManagerService()

        // Hook BatteryService
        hookBatteryService()

        // Hook PowerManagerService
        hookPowerManagerService()

        // Hook BatteryStats
        hookBatteryStats()

        enable()
    }

    /**
     * Hook ActivityManagerService
     */
    private fun hookActivityManagerService() {
        try {
            // Hook process limit methods
            XposedHelpers.findAndHookMethod(
                CLASS_ACTIVITY_MANAGER_SERVICE,
                null,
                "getProcessLimitLocked",
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Int>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val limit = configManager.getBackgroundLimit()
                        Logger.d(TAG, "后台进程限制: $limit")
                        // 修改限制值
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val defaultLimit = param.result as Int
                        val customLimit = configManager.getBackgroundLimit()
                        if (customLimit > 0 && customLimit != defaultLimit) {
                            param.result = customLimit
                            Logger.d(TAG, "后台进程限制: $defaultLimit -> $customLimit")
                        }
                    }
                }
            )

            // Hook isBackgroundRestricted
            XposedHelpers.findAndHookMethod(
                CLASS_ACTIVITY_MANAGER_SERVICE,
                null,
                "isBackgroundRestricted",
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val packageName = param.args[0] as String
                        Logger.d(TAG, "检查应用后台限制: $packageName")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 可以根据配置决定是否允许后台运行
                        val currentResult = param.result as Boolean
                        if (configManager.getBackgroundLimit() >= BACKGROUND_LIMIT_RESTRICTED) {
                            param.result = true
                            Logger.d(TAG, "强制后台限制: $currentResult -> true")
                        }
                    }
                }
            )

            // Hook process start
            XposedHelpers.findAndHookMethod(
                CLASS_ACTIVITY_MANAGER_SERVICE,
                null,
                "startProcessLocked",
                String::class.java,
                String::class.java,
                String::class.java,
                Int::class.javaPrimitiveType,
                String::class.java,
                object : XC_MethodHook<Any?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val processName = param.args[0] as String
                        val hostingType = param.args[3] as Int

                        // 根据主机类型决定是否启动
                        if (hostingType == 1 && configManager.getBackgroundLimit() >= BACKGROUND_LIMIT_RESTRICTED) {
                            // 后台服务启动
                            Logger.d(TAG, "阻止后台进程: $processName")
                        }
                    }
                }
            )

            Logger.d(TAG, "ActivityManagerService Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook ActivityManagerService 失败: ${e.message}")
        }
    }

    /**
     * Hook BatteryService
     */
    private fun hookBatteryService() {
        try {
            // Hook isPowered
            XposedHelpers.findAndHookMethod(
                CLASS_BATTERY_SERVICE,
                null,
                "isPowered",
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 可以用于省电模式优化
                        val plugType = param.args[0] as Int
                        Logger.d(TAG, "检查电源状态, plugType: $plugType")
                    }
                }
            )

            // Hook getBatteryLevel
            XposedHelpers.findAndHookMethod(
                CLASS_BATTERY_SERVICE,
                null,
                "getBatteryLevel",
                object : XC_MethodHook<Int>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val level = param.result as Int
                        // 可以用于电池百分比显示优化
                        Logger.d(TAG, "电池电量: $level%")
                    }
                }
            )

            Logger.d(TAG, "BatteryService Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook BatteryService 失败: ${e.message}")
        }
    }

    /**
     * Hook PowerManagerService
     */
    private fun hookPowerManagerService() {
        try {
            // Hook isPowerSaveMode
            XposedHelpers.findAndHookMethod(
                CLASS_POWER_MANAGER_SERVICE,
                null,
                "isPowerSaveMode",
                object : XC_MethodHook<Boolean>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val isPowerSave = param.result as Boolean
                        if (configManager.isBatterySaverEnhanced() && !isPowerSave) {
                            // 省电模式增强 - 在低电量时自动启用
                            Logger.d(TAG, "省电模式增强检查")
                        }
                    }
                }
            )

            // Hook acquireWakeLock
            XposedHelpers.findAndHookMethod(
                CLASS_POWER_MANAGER_SERVICE,
                null,
                "acquireWakeLock",
                Int::class.javaPrimitiveType,
                android.os.IBinder::class.java,
                String::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isBlockWakelock()) {
                            val tag = param.args[2] as String
                            // 可以选择性地阻止某些唤醒锁
                            Logger.d(TAG, "WakeLock 请求: $tag")
                            // param.result = null // 阻止获取唤醒锁
                        }
                    }
                }
            )

            Logger.d(TAG, "PowerManagerService Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook PowerManagerService 失败: ${e.message}")
        }
    }

    /**
     * Hook BatteryStats
     */
    private fun hookBatteryStats() {
        try {
            // Hook BatteryStatsImpl
            XposedHelpers.findAndHookMethod(
                "com.android.internal.os.BatteryStatsImpl",
                null,
                "getProcessStateStats",
                object : XC_MethodHook<Any?>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 用于获取进程功耗统计
                        Logger.d(TAG, "获取进程功耗统计")
                    }
                }
            )

            Logger.d(TAG, "BatteryStats Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook BatteryStats 失败: ${e.message}")
        }
    }

    /**
     * 获取当前后台限制级别描述
     */
    fun getBackgroundLimitDescription(): String {
        return when (configManager.getBackgroundLimit()) {
            BACKGROUND_LIMIT_NONE -> "无限制"
            BACKGROUND_LIMIT_MODERATE -> "适度限制 (3个进程)"
            BACKGROUND_LIMIT_RESTRICTED -> "严格限制 (4个进程)"
            BACKGROUND_LIMIT_GHOST -> "极度限制 (后台幽灵)"
            else -> "自定义: ${configManager.getBackgroundLimit()}"
        }
    }

    /**
     * 是否启用了省电增强
     */
    fun isEnhancedPowerSaveEnabled(): Boolean {
        return configManager.isBatterySaverEnhanced()
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "电池优化已启用 - ${getBackgroundLimitDescription()}")
    }
}
