package com.optimizer.coloros16.hooks

import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 通知栏优化 Hook
 *
 * 提供以下优化功能：
 * - 通知分组优化
 * - 通知历史记录
 * - 通知音效优化
 * - 通知渠道管理
 * - ColorOS 通知优化
 */
class NotificationHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "NotificationHook"

        // 目标类名
        private const val CLASS_NOTIFICATION_MANAGER = "com.android.server.notification.NotificationManagerService"
        private const val CLASS_NOTIFICATION_RECORD = "com.android.server.notification.NotificationRecord"
        private const val CLASS_NOTIFICATION_DELEGATES = "com.android.internal.notification.NotificationDelegants"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.systemui",
            "com.android.server",
            "com.coloros.system"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册通知栏优化 Hook...")

        // Hook 通知管理器
        hookNotificationManager()

        // Hook 通知记录
        hookNotificationRecord()

        // Hook 通知渠道
        hookNotificationChannel()

        // Hook 通知音效
        hookNotificationSound()

        enable()
    }

    /**
     * Hook 通知管理器
     */
    private fun hookNotificationManager() {
        try {
            // Hook enqueueNotification
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "enqueueNotification",
                String::class.java,
                String::class.java,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                android.os.UserHandle::class.java,
                android.app.Notification::class.java,
                Array<String>::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val pkg = param.args[0] as String
                        val tag = param.args[1] as String
                        val id = param.args[2] as Int
                        Logger.d(TAG, "入队通知: $pkg, tag=$tag, id=$id")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "通知入队完成")
                    }
                }
            )

            // Hook snoozeNotification
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "snoozeNotification",
                String::class.java,
                String::class.java,
                String::class.java,
                Long::class.javaPrimitiveType,
                String::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val pkg = param.args[0] as String
                        val key = param.args[1] as String
                        Logger.d(TAG, "延迟通知: $pkg, key=$key")
                    }
                }
            )

            // Hook cancelNotification
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "cancelNotification",
                String::class.java,
                String::class.java,
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val pkg = param.args[0] as String
                        val tag = param.args[1] as String
                        val id = param.args[2] as Int
                        Logger.d(TAG, "取消通知: $pkg, tag=$tag, id=$id")
                    }
                }
            )

            Logger.d(TAG, "NotificationManager Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NotificationManager 失败: ${e.message}")
        }
    }

    /**
     * Hook 通知记录
     */
    private fun hookNotificationRecord() {
        try {
            // Hook isGroupSummary
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_RECORD,
                null,
                "isGroupSummary",
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 优化分组逻辑
                        if (configManager.isNotificationGrouping()) {
                            Logger.d(TAG, "检查通知分组")
                        }
                    }
                }
            )

            // Hook getGroupKey
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_RECORD,
                null,
                "getGroupKey",
                object : XC_MethodHook<String>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isNotificationGrouping()) {
                            Logger.d(TAG, "获取分组键")
                        }
                    }
                }
            )

            // Hook shouldAutoGroup
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_RECORD,
                null,
                "shouldAutoGroup",
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isNotificationGrouping()) {
                            // 启用自动分组
                            param.result = true
                            Logger.d(TAG, "启用自动分组")
                        }
                    }
                }
            )

            Logger.d(TAG, "NotificationRecord Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NotificationRecord 失败: ${e.message}")
        }
    }

    /**
     * Hook 通知渠道
     */
    private fun hookNotificationChannel() {
        try {
            // Hook createNotificationChannel
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "createNotificationChannel",
                "android.app.NotificationChannel".loadClass(),
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val channel = param.args[0] as android.app.NotificationChannel
                        val channelId = channel.id
                        val importance = channel.importance
                        Logger.d(TAG, "创建通知渠道: $channelId, importance=$importance")
                    }
                }
            )

            // Hook createNotificationChannels
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "createNotificationChannels",
                java.util.List::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val channels = param.args[0] as java.util.List<*>
                        Logger.d(TAG, "批量创建通知渠道: ${channels.size} 个")
                    }
                }
            )

            // Hook getNotificationChannel
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "getNotificationChannel",
                String::class.java,
                String::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<android.app.NotificationChannel?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val pkg = param.args[0] as String
                        val channelId = param.args[1] as String
                        Logger.d(TAG, "获取通知渠道: $pkg/$channelId")
                    }
                }
            )

            Logger.d(TAG, "NotificationChannel Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NotificationChannel 失败: ${e.message}")
        }
    }

    /**
     * Hook 通知音效
     */
    private fun hookNotificationSound() {
        if (!configManager.isNotificationSound()) {
            Logger.d(TAG, "通知音效优化未启用")
            return
        }

        try {
            // Hook getSound
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "getSound",
                String::class.java,
                String::class.java,
                object : XC_MethodHook<android.net.Uri?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val pkg = param.args[0] as String
                        val channelId = param.args[1] as String
                        Logger.d(TAG, "获取通知音效: $pkg/$channelId")
                    }

                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val sound = param.result
                        if (sound != null) {
                            Logger.d(TAG, "通知音效: $sound")
                            // 可以在这里替换为优化后的音效
                        }
                    }
                }
            )

            // Hook shouldPlaySound
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "shouldPlaySound",
                CLASS_NOTIFICATION_RECORD,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isNotificationSound()) {
                            Logger.d(TAG, "检查是否播放音效")
                        }
                    }
                }
            )

            // Hook updateNotificationSound
            XposedHelpers.findAndHookMethod(
                CLASS_NOTIFICATION_MANAGER,
                null,
                "updateNotificationSound",
                CLASS_NOTIFICATION_RECORD,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "更新通知音效")
                    }
                }
            )

            Logger.d(TAG, "NotificationSound Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook NotificationSound 失败: ${e.message}")
        }
    }

    /**
     * 是否启用了通知分组
     */
    fun isNotificationGroupingEnabled(): Boolean {
        return configManager.isNotificationGrouping()
    }

    /**
     * 是否启用了通知历史
     */
    fun isNotificationHistoryEnabled(): Boolean {
        return configManager.isNotificationHistory()
    }

    /**
     * 是否启用了音效优化
     */
    fun isSoundOptimizationEnabled(): Boolean {
        return configManager.isNotificationSound()
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "通知栏优化已启用 - 分组: ${configManager.isNotificationGrouping()}, 历史: ${configManager.isNotificationHistory()}, 音效: ${configManager.isNotificationSound()}")
    }
}
