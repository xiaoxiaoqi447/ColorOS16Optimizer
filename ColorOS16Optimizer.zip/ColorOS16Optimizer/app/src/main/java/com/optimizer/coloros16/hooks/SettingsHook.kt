package com.optimizer.coloros16.hooks

import com.optimizer.coloros16.BaseHook
import com.optimizer.coloros16.ModuleEntry
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 系统设置增强 Hook
 *
 * 提供以下优化功能：
 * - 显示隐藏的设置项
 * - 开发者选项增强
 * - 备份功能优化
 * - 设置搜索优化
 * - ColorOS 设置定制
 */
class SettingsHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    companion object {
        private const val TAG = "SettingsHook"

        // 目标类名
        private const val CLASS_SETTINGS_PROVIDER = "com.android.providers.settings.SettingsProvider"
        private const val CLASS_SETTINGS_FRAGMENT = "com.android.settings.SettingsFragment"
        private const val CLASS_DEVELOPER_OPTIONS = "com.android.settings.DeveloperOptions"
        private const val CLASS_SETTINGS_PREFERENCE = "com.android.settingsPreference"
    }

    private val configManager = moduleEntry.getConfigManager()

    override fun getTag(): String = TAG

    override fun getTargetPackages(): List<String> {
        return listOf(
            "com.android.settings",
            "com.coloros.system",
            "com.coloros.safecenter"
        )
    }

    override fun register() {
        Logger.d(TAG, "注册系统设置增强 Hook...")

        // Hook 设置提供者
        hookSettingsProvider()

        // Hook 设置片段
        hookSettingsFragment()

        // Hook 开发者选项
        hookDeveloperOptions()

        // Hook 设置数据库
        hookSettingsDatabase()

        enable()
    }

    /**
     * Hook 设置提供者
     */
    private fun hookSettingsProvider() {
        try {
            // Hook getInt
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_PROVIDER,
                null,
                "getInt",
                android.database.sqlite.SQLiteDatabase::class.java,
                String::class.java,
                String::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Int>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val table = param.args[1] as String
                        val key = param.args[2] as String
                        Logger.d(TAG, "获取设置: $table/$key")
                    }
                }
            )

            // Hook getString
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_PROVIDER,
                null,
                "getString",
                android.database.sqlite.SQLiteDatabase::class.java,
                String::class.java,
                String::class.java,
                object : XC_MethodHook<String?>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val table = param.args[1] as String
                        val key = param.args[2] as String
                        Logger.d(TAG, "获取字符串设置: $table/$key")
                    }
                }
            )

            // Hook putString
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_PROVIDER,
                null,
                "putString",
                android.database.sqlite.SQLiteDatabase::class.java,
                String::class.java,
                String::class.java,
                String::class.java,
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val table = param.args[1] as String
                        val key = param.args[2] as String
                        val value = param.args[3] as String
                        Logger.d(TAG, "写入设置: $table/$key = $value")
                    }
                }
            )

            // Hook putInt
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_PROVIDER,
                null,
                "putInt",
                android.database.sqlite.SQLiteDatabase::class.java,
                String::class.java,
                String::class.java,
                String::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val table = param.args[1] as String
                        val key = param.args[2] as String
                        val value = param.args[3] as Int
                        Logger.d(TAG, "写入整型设置: $table/$key = $value")
                    }
                }
            )

            Logger.d(TAG, "SettingsProvider Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook SettingsProvider 失败: ${e.message}")
        }
    }

    /**
     * Hook 设置片段
     */
    private fun hookSettingsFragment() {
        if (!configManager.isShowHiddenSettings()) {
            Logger.d(TAG, "隐藏设置项未启用")
            return
        }

        try {
            // Hook onCreate
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_FRAGMENT,
                null,
                "onCreate",
                android.os.Bundle::class.java,
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "设置片段创建")
                        // 可以在这里添加隐藏的设置项
                    }
                }
            )

            // Hook onResume
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_FRAGMENT,
                null,
                "onResume",
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "设置片段恢复")
                    }
                }
            )

            // Hook getPreferenceScreenResId
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_FRAGMENT,
                null,
                "getPreferenceScreenResId",
                object : XC_MethodHook<Int>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 可以修改 preference 屏幕资源 ID
                        Logger.d(TAG, "获取 Preference 屏幕资源 ID")
                    }
                }
            )

            // Hook hasHint
            XposedHelpers.findAndHookMethod(
                CLASS_SETTINGS_FRAGMENT,
                null,
                "hasHint",
                String::class.java,
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isShowHiddenSettings()) {
                            // 强制显示隐藏设置
                            param.result = true
                            val key = param.args[0] as String
                            Logger.d(TAG, "显示隐藏设置项: $key")
                        }
                    }
                }
            )

            Logger.d(TAG, "SettingsFragment Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook SettingsFragment 失败: ${e.message}")
        }
    }

    /**
     * Hook 开发者选项
     */
    private fun hookDeveloperOptions() {
        if (!configManager.isDeveloperOptions()) {
            Logger.d(TAG, "开发者选项增强未启用")
            return
        }

        try {
            // Hook onResume
            XposedHelpers.findAndHookMethod(
                CLASS_DEVELOPER_OPTIONS,
                null,
                "onResume",
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "开发者选项恢复")
                    }
                }
            )

            // Hook enableHiddenSettings
            XposedHelpers.findAndHookMethod(
                CLASS_DEVELOPER_OPTIONS,
                null,
                "enableHiddenSettings",
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        if (configManager.isShowHiddenSettings()) {
                            Logger.d(TAG, "启用隐藏设置")
                        }
                    }
                }
            )

            // Hook isDebuggable
            XposedHelpers.findAndHookMethod(
                CLASS_DEVELOPER_OPTIONS,
                null,
                "isDebuggable",
                object : XC_MethodHook<Boolean>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        // 可以强制启用开发者选项
                        if (configManager.isDeveloperOptions()) {
                            param.result = true
                            Logger.d(TAG, "强制启用开发者选项")
                        }
                    }
                }
            )

            // Hook updateADBEnabled
            XposedHelpers.findAndHookMethod(
                CLASS_DEVELOPER_OPTIONS,
                null,
                "updateADBEnabled",
                Boolean::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        val enabled = param.args[0] as Boolean
                        Logger.d(TAG, "更新 ADB: $enabled")
                    }
                }
            )

            Logger.d(TAG, "DeveloperOptions Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook DeveloperOptions 失败: ${e.message}")
        }
    }

    /**
     * Hook 设置数据库
     */
    private fun hookSettingsDatabase() {
        try {
            // Hook DatabaseHelper.onCreate
            XposedHelpers.findAndHookMethod(
                "com.android.providers.settings.SettingsDatabaseHelper",
                null,
                "onCreate",
                android.database.sqlite.SQLiteDatabase::class.java,
                object : XC_MethodHook<Any>() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "设置数据库创建")
                    }
                }
            )

            // Hook insertSecureSettings
            XposedHelpers.findAndHookMethod(
                "com.android.providers.settings.SettingsDatabaseHelper",
                null,
                "insertSecureSettings",
                android.database.sqlite.SQLiteDatabase::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "插入安全设置")
                    }
                }
            )

            // Hook getSecureSettings
            XposedHelpers.findAndHookMethod(
                "com.android.providers.settings.SettingsDatabaseHelper",
                null,
                "getSecureSettings",
                android.database.sqlite.SQLiteDatabase::class.java,
                object : XC_MethodHook<Any>() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (!isEnabled) return

                        Logger.d(TAG, "获取安全设置")
                    }
                }
            )

            Logger.d(TAG, "SettingsDatabase Hook 完成")
        } catch (e: Exception) {
            Logger.e(TAG, "Hook SettingsDatabase 失败: ${e.message}")
        }
    }

    /**
     * 是否启用了隐藏设置项
     */
    fun isHiddenSettingsEnabled(): Boolean {
        return configManager.isShowHiddenSettings()
    }

    /**
     * 是否启用了开发者选项增强
     */
    fun isDeveloperOptionsEnabled(): Boolean {
        return configManager.isDeveloperOptions()
    }

    /**
     * 是否启用了备份优化
     */
    fun isBackupOptimizationEnabled(): Boolean {
        return configManager.isBackupOptimization()
    }

    override fun enable() {
        super.enable()
        Logger.i(TAG, "系统设置增强已启用 - 隐藏设置: ${configManager.isShowHiddenSettings()}, 开发者选项: ${configManager.isDeveloperOptions()}")
    }
}
