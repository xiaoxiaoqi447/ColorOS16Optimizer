package com.optimizer.coloros16.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.preference.PreferenceFragmentCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView
import com.optimizer.coloros16.R
import com.optimizer.coloros16.config.ConfigManager
import com.optimizer.coloros16.utils.Logger

/**
 * 模块配置界面 Activity
 *
 * 提供图形化的配置界面
 */
class ModuleActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "ModuleActivity"
    }

    private lateinit var configManager: ConfigManager
    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_module)

        // 初始化配置管理器
        configManager = ConfigManager.getInstance()
        if (!::configManager.isInitialized) {
            configManager.init(this)
        }

        // 设置 Toolbar
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = getString(R.string.app_name)

        // 设置底部导航
        bottomNav = findViewById(R.id.bottom_navigation)

        // 如果是首次启动，显示模块信息
        if (savedInstanceState == null) {
            showModuleInfo()
        }

        setupBottomNavigation()

        Logger.i(TAG, "ModuleActivity 创建完成")
    }

    private fun setupBottomNavigation() {
        bottomNav.setOnItemSelectedListener(NavigationBarView.OnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_system -> {
                    showFragment(SystemSettingsFragment())
                    supportActionBar?.title = getString(R.string.category_system)
                    true
                }
                R.id.nav_animation -> {
                    showFragment(AnimationSettingsFragment())
                    supportActionBar?.title = getString(R.string.category_animation)
                    true
                }
                R.id.nav_battery -> {
                    showFragment(BatterySettingsFragment())
                    supportActionBar?.title = getString(R.string.category_battery)
                    true
                }
                R.id.nav_privacy -> {
                    showFragment(PrivacySettingsFragment())
                    supportActionBar?.title = getString(R.string.category_privacy)
                    true
                }
                else -> false
            }
        })
    }

    private fun showFragment(fragment: PreferenceFragmentCompat) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit()
    }

    private fun showModuleInfo() {
        // 显示模块信息对话框
        val versionInfo = """
            ColorOS 16 优化器
            版本: ${getString(R.string.module_version)}

            系统版本: Android ${Build.VERSION.RELEASE}
            ColorOS 版本: 16

            功能:
            - 系统动画优化
            - 电池优化
            - 网络优化
            - 主题定制
            - 状态栏优化
            - 通知栏优化
            - 系统设置增强
            - 隐私增强

            注意: 需要重启设备才能生效
        """.trimIndent()

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_name))
            .setMessage(versionInfo)
            .setPositiveButton("确定") { dialog, _ ->
                dialog.dismiss()
                // 默认显示系统设置
                showFragment(SystemSettingsFragment())
            }
            .setCancelable(false)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_about -> {
                showAboutDialog()
                true
            }
            R.id.action_reset -> {
                showResetConfirmDialog()
                true
            }
            R.id.action_export -> {
                exportConfig()
                true
            }
            R.id.action_import -> {
                importConfig()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAboutDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.about))
            .setMessage("ColorOS 16 优化器\n版本: ${getString(R.string.module_version)}\n\n提供 ColorOS 16 系统全面优化功能")
            .setPositiveButton("确定", null)
            .show()
    }

    private fun showResetConfirmDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.reset))
            .setMessage("确定要重置所有配置吗？")
            .setPositiveButton("确定") { _, _ ->
                configManager.resetAll()
                Toast.makeText(this, "配置已重置", Toast.LENGTH_SHORT).show()
                Logger.i(TAG, "配置已重置")
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun exportConfig() {
        try {
            val config = configManager.exportConfig()
            // 复制到剪贴板
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("ColorOS16 Config", config)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "配置已复制到剪贴板", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "导出失败: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importConfig() {
        Toast.makeText(this, "请在文本框中粘贴配置", Toast.LENGTH_LONG).show()
        // 可以添加导入对话框
    }

    override fun onResume() {
        super.onResume()
        Logger.d(TAG, "ModuleActivity 恢复")
    }

    override fun onPause() {
        super.onPause()
        Logger.d(TAG, "ModuleActivity 暂停")
    }

    override fun onDestroy() {
        super.onDestroy()
        Logger.i(TAG, "ModuleActivity 销毁")
    }
}

/**
 * 系统设置 Fragment
 */
class SystemSettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences_system, rootKey)

        // 初始化配置
        val configManager = ConfigManager.getInstance()

        // 模块总开关
        findPreference<androidx.preference.SwitchPreference>("module_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setModuleEnabled(newValue as Boolean)
            true
        }

        // 网络优化
        findPreference<androidx.preference.SwitchPreference>("network_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setNetworkEnabled(newValue as Boolean)
            true
        }

        // 主题定制
        findPreference<androidx.preference.SwitchPreference>("theme_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setThemeEnabled(newValue as Boolean)
            true
        }

        // 状态栏优化
        findPreference<androidx.preference.SwitchPreference>("statusbar_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setStatusBarEnabled(newValue as Boolean)
            true
        }

        // 通知栏优化
        findPreference<androidx.preference.SwitchPreference>("notification_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setNotificationEnabled(newValue as Boolean)
            true
        }

        // 系统设置
        findPreference<androidx.preference.SwitchPreference>("settings_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setSettingsEnabled(newValue as Boolean)
            true
        }
    }
}

/**
 * 动画设置 Fragment
 */
class AnimationSettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences_animation, rootKey)

        val configManager = ConfigManager.getInstance()

        // 动画总开关
        findPreference<androidx.preference.SwitchPreference>("animation_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setAnimationEnabled(newValue as Boolean)
            true
        }

        // 动画速度
        findPreference<androidx.preference.ListPreference>("animation_speed")?.setOnPreferenceChangeListener { _, newValue ->
            val speed = when (newValue as String) {
                "0" -> 0f      // 禁用
                "0.5" -> 0.5f  // 快速
                "1.0" -> 1.0f  // 默认
                "1.5" -> 1.5f  // 较慢
                "2.0" -> 2.0f  // 最慢
                else -> 1.0f
            }
            configManager.setAnimationSpeed(speed)
            true
        }

        // 禁用动画
        findPreference<androidx.preference.SwitchPreference>("disable_animation")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setDisableAnimation(newValue as Boolean)
            true
        }
    }
}

/**
 * 电池设置 Fragment
 */
class BatterySettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences_battery, rootKey)

        val configManager = ConfigManager.getInstance()

        // 电池优化总开关
        findPreference<androidx.preference.SwitchPreference>("battery_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setBatteryEnabled(newValue as Boolean)
            true
        }

        // 后台限制
        findPreference<androidx.preference.ListPreference>("background_limit")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setBackgroundLimit((newValue as String).toInt())
            true
        }

        // 省电增强
        findPreference<androidx.preference.SwitchPreference>("battery_saver_enhanced")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setBatterySaverEnhanced(newValue as Boolean)
            true
        }

        // 阻止唤醒锁
        findPreference<androidx.preference.SwitchPreference>("block_wakelock")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setBlockWakelock(newValue as Boolean)
            true
        }
    }
}

/**
 * 隐私设置 Fragment
 */
class PrivacySettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences_privacy, rootKey)

        val configManager = ConfigManager.getInstance()

        // 隐私增强总开关
        findPreference<androidx.preference.SwitchPreference>("privacy_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setPrivacyEnabled(newValue as Boolean)
            true
        }

        // 权限管理
        findPreference<androidx.preference.SwitchPreference>("permission_management")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setPermissionManagement(newValue as Boolean)
            true
        }

        // 追踪保护
        findPreference<androidx.preference.SwitchPreference>("tracking_protection")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setTrackingProtection(newValue as Boolean)
            true
        }

        // 麦克风保护
        findPreference<androidx.preference.SwitchPreference>("microphone_protection")?.setOnPreferenceChangeListener { _, newValue ->
            configManager.setMicrophoneProtection(newValue as Boolean)
            true
        }
    }
}
