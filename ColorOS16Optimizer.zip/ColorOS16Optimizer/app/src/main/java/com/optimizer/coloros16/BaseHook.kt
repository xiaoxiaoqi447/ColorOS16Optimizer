package com.optimizer.coloros16

import android.content.Context
import android.content.res.XModuleResources
import android.content.res.XResources
import com.optimizer.coloros16.utils.Logger
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.callbacks.XC_LoadPackage
import org.lsposed.lsplant.hook.Hook

/**
 * 基础 Hook 类
 *
 * 所有具体的 Hook 实现都应继承此类
 * 提供了通用的 Hook 功能和方法
 */
abstract class BaseHook(protected val moduleEntry: ModuleEntry) : Hook() {

    companion object {
        protected const val TAG = "BaseHook"
    }

    protected var isEnabled = false
    protected val modulePackage = ModuleEntry.MODULE_PACKAGE

    /**
     * 注册 Hook
     * 子类需要重写此方法来执行具体的 Hook 注册逻辑
     */
    abstract fun register()

    /**
     * 启用 Hook
     */
    open fun enable() {
        isEnabled = true
        Logger.d(getTag(), "Hook 已启用")
    }

    /**
     * 禁用 Hook
     */
    open fun disable() {
        isEnabled = false
        Logger.d(getTag(), "Hook 已禁用")
    }

    /**
     * 获取 Hook 的标签
     */
    protected abstract fun getTag(): String

    /**
     * 检查包名是否是目标包
     */
    protected fun isTargetPackage(packageName: String?, targets: List<String>): Boolean {
        return targets.any { target ->
            packageName?.contains(target, ignoreCase = true) == true
        }
    }

    /**
     * 获取目标包列表
     */
    protected abstract fun getTargetPackages(): List<String>

    /**
     * Hook 包加载
     */
    fun hookPackage(lpparam: XC_LoadPackage.LoadPackageParam, hookLogic: (XC_LoadPackage.LoadPackageParam) -> Unit) {
        if (isTargetPackage(lpparam.packageName, getTargetPackages())) {
            Logger.d(getTag(), "Hook 包: ${lpparam.packageName}")
            hookLogic(lpparam)
        }
    }
}

/**
 * Hook 配置接口
 */
interface HookConfig {
    fun isEnabled(): Boolean
    fun getPriority(): Int = 0
}

/**
 * 运行时 Hook 接口
 * 用于需要在运行时动态启用的 Hook
 */
interface RuntimeHook {
    fun applyRuntimeConfig()
    fun removeRuntimeConfig()
}
