# ColorOS 16 优化器

## 项目简介

ColorOS 16 优化器是一个功能强大的 LSPosed (LSP) 模块，专为 ColorOS 16 系统设计。它提供了全面的系统优化功能，包括动画优化、电池优化、网络优化、主题定制、状态栏优化、通知栏优化、系统设置增强和隐私增强。

## 功能特性

### 系统优化
- **动画优化**: 调整系统动画速度，支持完全禁用动画
- **电池优化**: 后台进程限制、省电模式增强、唤醒锁管理
- **网络优化**: DNS 优化、TCP 优化、IPv6 优化
- **主题定制**: 解锁主题限制、图标包支持、壁纸优化
- **状态栏优化**: 显示网速、电池百分比、自定义时钟格式
- **通知栏优化**: 通知分组、通知历史、通知音效
- **系统设置增强**: 显示隐藏设置项、开发者选项增强
- **隐私增强**: 权限管理、追踪保护、麦克风保护

## 技术架构

### 模块结构
```
com.optimizer.coloros16/
├── ModuleEntry.kt          # LSP 模块入口
├── BaseHook.kt             # 基础 Hook 类
├── config/
│   └── ConfigManager.kt    # 配置管理器
├── hooks/
│   ├── AnimationHook.kt    # 动画优化
│   ├── BatteryHook.kt      # 电池优化
│   ├── NetworkHook.kt      # 网络优化
│   ├── ThemeHook.kt        # 主题定制
│   ├── StatusBarHook.kt    # 状态栏优化
│   ├── NotificationHook.kt  # 通知栏优化
│   ├── SettingsHook.kt     # 系统设置
│   └── PrivacyHook.kt      # 隐私增强
├── ui/
│   └── ModuleActivity.kt   # 配置界面
└── utils/
    └── Logger.kt           # 日志工具
```

## 环境要求

- Android 14+ (ColorOS 14/15/16)
- LSPosed Framework
- Root 权限

## 安装说明

### 编译模块

1. 克隆项目到本地
2. 使用 Android Studio 打开项目
3. 同步 Gradle 文件
4. 构建 Release 版本
5. 在 LSPosed Manager 中激活模块

### 安装步骤

1. 将编译好的 APK 安装到设备
2. 打开 LSPosed Manager
3. 在模块列表中找到 "ColorOS 16 优化器"
4. 勾选要优化的应用（建议全选系统应用）
5. 启用模块
6. 重启设备

## 使用说明

### 基本配置

1. 打开应用进入配置界面
2. 根据需要启用/禁用各项功能
3. 部分功能需要重启设备生效
4. 可导出/导入配置进行备份

### 功能详解

#### 动画优化
- **动画速度**: 提供 5 档可选速度
- **禁用动画**: 完全禁用所有系统动画
- **独立设置**: 可分别设置窗口动画、过渡动画、Animator 时长

#### 电池优化
- **后台限制**: 选择不同的后台进程限制级别
- **唤醒锁**: 可选择性阻止应用持有唤醒锁
- **省电增强**: 增强系统省电模式效果

#### 网络优化
- **DNS 优化**: 优化 DNS 解析速度
- **TCP 优化**: 优化 TCP 连接参数
- **IPv6 优化**: 优化 IPv6 连接性能

#### 隐私增强
- **权限管理**: 增强应用权限管理功能
- **追踪保护**: 阻止应用追踪行为
- **麦克风保护**: 增强麦克风使用保护

## 开发说明

### 添加新的 Hook

1. 在 `hooks/` 目录下创建新的 Hook 类
2. 继承 `BaseHook` 类
3. 实现必要的方法
4. 在 `ModuleEntry` 中注册 Hook

### 示例代码

```kotlin
class CustomHook(moduleEntry: ModuleEntry) : BaseHook(moduleEntry) {

    override fun getTag(): String = "CustomHook"

    override fun getTargetPackages(): List<String> {
        return listOf("com.example.app")
    }

    override fun register() {
        // 注册 Hook
        enable()
    }
}
```

## 兼容性

- Android 14 (API 34)
- Android 15 (API 35)
- ColorOS 14/15/16

## 常见问题

### Q: 模块未生效怎么办？
A: 请确保已在 LSPosed Manager 中启用模块并勾选了目标应用，然后重启设备。

### Q: 部分功能不工作？
A: 某些功能可能需要特定的 ColorOS 版本支持，请查看日志了解详情。

### Q: 如何获取日志？
A: 模块使用统一的日志系统，可在 Logcat 中过滤 "ColorOS16" 标签查看。

## 更新日志

### v1.0.0
- 初始版本发布
- 支持所有主要优化功能
- 提供图形化配置界面

## 致谢

- LSPosed Team - 提供优秀的 Xposed 框架
- Android 开放源代码项目

## 许可证

本项目仅供学习和研究使用，请勿用于商业目的。
