# ColorOS 16 优化器 - GitHub 上传指南

## 📋 上传步骤

### 第一步：创建 GitHub 仓库

1. 登录您的 GitHub 账号
2. 点击右上角的 **"+"** 按钮，选择 **"New repository"**
3. 填写仓库信息：
   - **Repository name**: `ColorOS16Optimizer`
   - **Description**: `ColorOS 16 系统优化 LSP 模块`
   - **选择 Public**（公开仓库才能使用 GitHub Actions 免费额度）
   - ✅ 勾选 **"Add a README file"**
   - ✅ 勾选 **"Add .gitignore"**，选择 **Android** 模板

4. 点击 **"Create repository"**

### 第二步：上传项目文件

**方法 A：使用 GitHub 网页上传（简单推荐）**

1. 进入您刚创建的空仓库
2. 点击 **"uploading an existing file"**
3. 将我提供的所有项目文件拖拽到上传区域
4. 确保包含以下关键文件和文件夹：
   ```
   .github/
   app/
   gradle/
   build.gradle
   settings.gradle
   gradle.properties
   README.md
   ```
5. 点击 **"Commit changes"**

**方法 B：使用 Git 命令行**

```bash
# 在本地电脑打开终端，克隆空仓库
git clone https://github.com/您的用户名/ColorOS16Optimizer.git

# 进入仓库目录
cd ColorOS16Optimizer

# 复制所有项目文件到此处

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit: ColorOS16 Optimizer LSP Module"

# 推送到 GitHub
git push -u origin main
```

### 第三步：等待自动编译

1. 上传完成后，点击仓库顶部的 **"Actions"** 标签
2. 您会看到构建任务自动开始
3. 点击最新的构建任务查看进度
4. 等待 5-10 分钟，编译完成

### 第四步：下载 APK

1. 编译完成后，点击构建任务
2. 在页面底部找到 **"Artifacts"** 部分
3. 下载 **release-apk** 或 **debug-apk**
4. 将 APK 文件传输到您的 ColorOS 16 设备
5. 安装并激活模块

## 🔧 如果构建失败怎么办？

### 常见错误及解决方案

**错误 1：Java 版本不对**
```
Expected JDK 17, found JDK 11
```
解决：workflow 文件已配置 JDK 17，如果仍有问题，检查是否使用了自定义 runner

**错误 2：Gradle 同步失败**
```
Could not resolve dependencies
```
解决：这通常是网络问题，GitHub Actions 会自动重试。如果持续失败，可能是依赖库问题。

**错误 3：SDK 许可问题**
```
SDK license not accepted
```
解决：在 workflow 中已添加许可接受步骤，如果仍有问题，检查 Android SDK 配置

## 📱 安装和激活模块

### 安装 APK

1. 将下载的 APK 传输到手机
2. 在手机上打开 APK 文件
3. 如果提示"禁止安装未知来源应用"，请先在设置中允许
4. 完成安装

### 激活模块

1. 打开 **LSPosed Manager** 应用
2. 在模块列表中找到 **"ColorOS 16 优化器"**
3. 点击进入，点击顶部的开关启用模块
4. 在"作用域"中选择要优化的应用（建议全选系统应用）
5. **重启设备**

### 验证激活

1. 重启后打开 LSPosed Manager
2. 查看模块状态是否显示"已激活"
3. 打开模块配置应用，调整各项优化设置

## ⚙️ 自定义配置

### 修改目标 Android 版本

如果您需要针对不同 Android 版本，编辑 `app/build.gradle`：

```gradle
android {
    compileSdk 34  // 编译 SDK 版本
    minSdk 24      // 最低支持版本
    targetSdk 34   // 目标 SDK 版本
}
```

### 添加更多 Hook

在 `app/src/main/java/com/optimizer/coloros16/hooks/` 目录下创建新的 Hook 类，然后在 `ModuleEntry.kt` 中注册。

## 🔄 更新模块

当您修改代码后：

1. 将更新推送到 GitHub
2. GitHub Actions 自动重新编译
3. 在 Actions 页面下载新的 APK
4. 重新安装到手机

## ❓ 获取帮助

如果遇到问题：

1. 查看 GitHub Actions 的构建日志
2. 在仓库的 Issues 页面提问
3. 检查 README.md 了解模块功能

## 📄 许可证

本项目仅供学习和个人使用，请勿用于商业目的。

---

**祝您使用愉快！** 🎉
